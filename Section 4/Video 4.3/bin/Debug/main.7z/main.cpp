#include <iostream>
#include <fstream>
#include <cstring>

int main()
{
    std::ifstream inBinaryFile;
    inBinaryFile.open("main.zip", std::ios::binary);
    char* readBuffer = new char[4];
    const char magicWords[4] = { '\x50', '\x4b', '\x03', '\x04' };
    inBinaryFile.read(readBuffer, 4);
    inBinaryFile.close();
    if (std::memcmp(readBuffer, magicWords, 4) == 0)
    {
        std::cout << "It is a ZIP file!\n";
    }
    else
    {
        std::cout << "It is NOT a ZIP file!\n";
    }
    return 0;
}
